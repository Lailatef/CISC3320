#!/bin/csh 
# print the following
echo "Welcome to this cshell script, enter one of the following: "
echo "  "
echo "list:         list files and directory of a given directory" 
echo "history:      list commands entered in the past" 
echo "printwd:      print current working directory" 
echo "chdir:        change to a given directory" 
echo "run:          run an external program with command line arguments" 
echo "exit:         exit the script" 

set my_list = () # set an empty list
set i = 0 # set a counter to zero


while ({ true }) # enter in infinite loop and always read user input
set INPUT1 = $< # get input from user 
if ($INPUT1 == 'exit') then # if input is "exit", then exit program
    exit 1 # quit
else
    if ($INPUT1 == 'list') then   # if input is "list", then print the list of files and directores of the given directory"
        ls
        set my_list = ($my_list list)
    else
        if ($INPUT1 == 'history') then # if input is "history", then  list commands entered in the past"
            history
            echo $my_list
            set my_list = ($my_list history) 
        else
            if ($INPUT1 == 'printwd') then # if input is "printwd", then  print current working directory
                pwd
                set my_list = ($my_list printwd)
            else
                if ($INPUT1 == 'chdir') then # if input is "chdir", then change to a given directory
                    echo "Please enter a directory you would want to navigate to. Ex: /Users/"
                    set INPUT2 = $<
                    cd $INPUT2
                    set my_list = ($my_list chdir)
                else
                    if ($INPUT1 == 'run') then # if input is "run", then change to a given directory
                        echo "Please enter the full path of the program you want to run. Ex ./helloworld"
                        set INPUT2 = $<
                        $INPUT2
                        set my_list = ($my_list run)
                    else
                        echo "Invalid command. Please enter a valid one." # else print "Invalid command. Please enter a valid one."
                    endif
                endif
            endif
        endif
    endif
endif
 @ i += 1  #increment by 1 each time to keep track of history
end



